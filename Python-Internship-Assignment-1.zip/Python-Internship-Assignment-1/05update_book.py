import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

cd=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %cd)
data=curs.fetchone()

try:
    print('Bookname: %s | Category: %s | Author: %s | Publication: %s | Edition: %d | Price: %.2f' %(data[1],data[2],data[3],data[4],data[5],data[6]))
except:
    print('Book not found')

    print('Do you want to add the book?')
    ans=input()
    if ans.lower()=='yes':
      nm=input('Enter Book Name: ')
      ct=input('Enter Book Category: ')
      au=input('Enter Book Auther Name: ')
      pb=input('Enter Book Publication: ')
      ed=int(input('Enter Book Edition: '))
      pr=float(input('Enter Book Price: '))
      rv=input('Enter Book Review: ')

      curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f,'%s')" %(cd,nm,ct,au,pb,ed,pr,rv))
      con.commit()
      print('Book is added successfully')
    else:   
       print('OK')  


con.close()    