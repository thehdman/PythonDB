import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

cd=int(input('Enter Book Code: '))
nm=input('Enter Book Name: ')
ct=input('Enter Book Category: ')
au=input('Enter Book Auther Name: ')
pb=input('Enter Book Publication: ')
ed=int(input('Enter Book Edition: '))
pr=float(input('Enter Book Price: '))
rv=input('Enter Book Review: ')

try:
    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f,'%s')" %(cd,nm,ct,au,pb,ed,pr,rv))
    con.commit()
    print('Book is added successfully')
except Exception as e:
    print('Data insert failed - ',e)

con.close()