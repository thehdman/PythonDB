import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

curs.execute("alter table books add column review varchar(500)")

con.close()