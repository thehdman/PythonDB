import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

no=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %no)
data=curs.fetchone()
 
print('Bookname: %s | Category: %s | Author: %s | Publication: %s | Edition: %d | Price: %.2f' %(data[1],data[2],data[3],data[4],data[5],data[6]))

print('Review the book') 
rv=input()
curs.execute("Update books set review='%s' where bookcd=%d" %(rv,no))
con.commit()
print('Review added successfully')

con.close()