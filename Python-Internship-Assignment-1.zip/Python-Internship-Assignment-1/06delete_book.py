import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

no=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %no)
data=curs.fetchone()

print(data)

print('Do you want to delete?')
ans=input()
if ans.lower()=='yes':
    curs.execute("delete from books where bookcd=%d" %no)
    con.commit()
    print('Book is delete successfully')
else:    
    print('Book is not deleted')

con.close()    