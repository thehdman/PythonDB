import pymysql

con=pymysql.connect(host='bnagvdx1qrtsgeqjujko-mysql.services.clever-cloud.com', user='u7wnlx6zr7jhhfhl', password='eEuTbRy8bgz2dLgDI76b', database='bnagvdx1qrtsgeqjujko')
curs=con.cursor()

au=input('Enter Book Auther Name: ')
pb=input('Enter Book Publication: ')

curs.execute("select * from books where bookau='%s' and bookpb='%s'" %(au,pb))
data=curs.fetchall()

for rec in data:
    print('%s' %(rec[1]))

con.close

